# react-slider
Simple react slider component with touch support and 0 dependencies.

### [Demo](https://stanko.github.io/react-slider)

[![](http://stanko.github.io/public/img/projects/react-slider.png)](https://stanko.github.io/react-slider)

### TypeScript version

Make sure you check the [TypeScript version](https://github.com/Stanko/react-slider/issues/8), made by @mindplay-dk

-----

Licenced under [MIT license](https://github.com/Stanko/react-slider/blob/gh-pages/LICENSE.md).
